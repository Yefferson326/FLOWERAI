

export interface User {
    cliente:        string;
    codigo_cliente: number;
    contacto:       string;
    lugar:          string;
}

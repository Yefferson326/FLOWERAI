import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { User } from '../models/user';
import { Color, ScaleType } from '@swimlane/ngx-charts';

@Injectable({
  providedIn: 'root'
})
export class GraphicsService {

  url = 'http://localhost:3000'
  selectedOptions?: string[] = [];
  colorScheme: Color = {
    group: ScaleType.Linear,
    name: '',
    selectable: true,
    domain: ['#5AA454', '#E44D25', '#CFC0BB', '#7aa3e5', '#a8385d', '#aae3f5']
  };
  
  
  constructor(private http: HttpClient) { }

  getCategoriesList() {
    return firstValueFrom(this.http.get(`${this.url}/stats/categories`));
  }
  getProductsList() {
    return firstValueFrom(this.http.get(`${this.url}/stats/products`));
  }

  getDatagraphs(selectedProducts: string) {
    return firstValueFrom(this.http.get<string>(`${this.url}/stats/grafica1/${selectedProducts}`));
  }
  getDatacard1() {
    return firstValueFrom(this.http.get<string>(`${this.url}/stats/card1`));
  }
  getDatacard2() {
    return firstValueFrom(this.http.get<string>(`${this.url}/stats/card2`));
  }
  getDatacard3() {
    return firstValueFrom(this.http.get<string>(`${this.url}/stats/card3`));
  }
  getDatacard4(selectedProducts: any) {
    // seleccionar el string de la posicion cero del array
    // selectedProducts = selectedProducts[0]
    // convierta a string el array
    selectedProducts = selectedProducts.toString()
    console.log("selectedProducts in service")
    console.log(selectedProducts)
    return firstValueFrom(this.http.get<string>(`${this.url}/stats/card4/${selectedProducts}`));
  }
  getDatagraphic1() {
    return firstValueFrom(this.http.get(`${this.url}/stats/graphic1tree`));
  }


}

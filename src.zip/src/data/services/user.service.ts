import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { firstValueFrom } from 'rxjs';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url = 'http://localhost:3000'
  idUser?:number
  actualUser?: User;
  

  constructor(private http: HttpClient) { }

  getClients(textToSearch?: string) {
    const url = !textToSearch ? `${this.url}/users` : `${this.url}/users/${textToSearch}`
    return firstValueFrom(this.http.get<User[] | User>(url));
  }
  
  deleteClient(id: number) {
    return firstValueFrom(this.http.delete(`${this.url}/users/${id}`));
  }
  updateUser(fields: any) {
    return firstValueFrom(this.http.put(`${this.url}/users/${fields.id}`, { ...fields }));
  }
  createUser(fields: any) {
    return firstValueFrom(this.http.post(`${this.url}/users`, { ...fields }));
  }

}

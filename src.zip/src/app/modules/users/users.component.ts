import { LiveAnnouncer } from '@angular/cdk/a11y';
import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatSort, Sort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { User } from 'src/data/models/user';
import { ModalService } from 'src/data/services/modal.service';
import { UserService } from 'src/data/services/user.service';
import { DeleteConfirmationComponent } from './components/delete-confirmation/delete-confirmation.component';
import { UserFormComponent } from './components/user-form/user-form.component';
@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit, AfterViewInit{

  value = '';
  displayedColumns: string[] = ['codigo_cliente','cliente', 'contacto', 'lugar','acciones'];
  userList: User[] = [];
  ELEMENT_DATA_1: User[] = [];

  dataSource = new MatTableDataSource(this.userList);
  
  formSearch: FormGroup = this.fb.group({
    textToSearch: ''
  });

  constructor(private userService: UserService, private _liveAnnouncer: LiveAnnouncer, private fb: FormBuilder,private modalService: ModalService ) {}
  
  ngOnInit(): void {
    this.getDataUsers()

  }

  async getDataUsers() {
    console.log(this.formSearch.value.textToSearch)
    try {
      const response = await this.userService.getClients(this.formSearch.value.textToSearch)
      this.userList = response instanceof Array ? response as User[] : [response]
    } catch (error) {
      this.userList = []
    }
    this.updateElementData()
  }

  updateElementData() {
    this.ELEMENT_DATA_1 = this.userList.map((user) => ({
      cliente: user.cliente,
      codigo_cliente: user.codigo_cliente,
      contacto: user.contacto,
      lugar: user.lugar
    }));
    this.dataSource.data = this.ELEMENT_DATA_1;
    this.dataSource.sort = this.sort;
  }

  @ViewChild(MatSort)
  sort: MatSort = new MatSort;
  
  ngAfterViewInit() {
    this.dataSource.sort = this.sort;
  }

  /** Announce the change in sort state for assistive technology. */
  announceSortChange(sortState: Sort) {
    // This example uses English messages. If your application supports
    // multiple language, you would internationalize these strings.
    // Furthermore, you can customize the message to add additional
    // details about the values being sorted.
    if (sortState.direction) {
      this._liveAnnouncer.announce(`Sorted ${sortState.direction}ending`);
    } else {
      this._liveAnnouncer.announce('Sorting cleared');
    }
  }
  clearFilter() {
    this.formSearch.reset()
    this.getDataUsers()
  }

  async showDialog(user: User | undefined, option: number) {
    switch (option) {
      case 0:
        this.userService.actualUser = user
        this.modalService.open(UserFormComponent, () => {
          this.getDataUsers();
        })
        break;
      case 1:
        this.userService.idUser = user?.codigo_cliente
        this.modalService.open(DeleteConfirmationComponent, () => {
          this.getDataUsers();
        })
        // Cuando se cierra el modal se van a volver a llamar los datos
        break;
    }
  }
}

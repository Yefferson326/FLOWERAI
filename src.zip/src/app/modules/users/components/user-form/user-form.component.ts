import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { UserService } from 'src/data/services/user.service';

@Component({
  selector: 'app-user-form',
  templateUrl: './user-form.component.html',
  styleUrls: ['./user-form.component.css']
})
export class UserFormComponent {

  formUser: FormGroup = this.fb.group({
    "cliente": this.userServices.actualUser? this.userServices.actualUser.cliente : '',
    "contacto": this.userServices.actualUser? this.userServices.actualUser.contacto : '',
    "lugar":  this.userServices.actualUser? this.userServices.actualUser.lugar : ''
  });
  cliente = this.userServices.actualUser ? this.userServices.actualUser.cliente : '';

  constructor(private fb: FormBuilder, private dialogRef: MatDialogRef<UserFormComponent>, private userServices: UserService) { }  

  close() {
    this.dialogRef.close();
  }

  async createOrUpdate() {
    if(this.userServices.actualUser){
      await this.userServices.updateUser({ id: this.userServices.actualUser.codigo_cliente, ...this.formUser.value });
      this.dialogRef.close()
    }else{
      await this.userServices.createUser(this.formUser.value);
      this.dialogRef.close()
    }
  }

}

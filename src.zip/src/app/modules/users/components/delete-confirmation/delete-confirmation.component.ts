import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { UserService } from 'src/data/services/user.service';

@Component({
  selector: 'app-delete-confirmation',
  templateUrl: './delete-confirmation.component.html',
  styleUrls: ['./delete-confirmation.component.css']
})
export class DeleteConfirmationComponent {
  constructor(private dialogRef: MatDialogRef<DeleteConfirmationComponent>, private userService: UserService) { }

  close() {
    this.dialogRef.close();
  }

  async deleteUser() {
    await this.userService.deleteClient(this.userService.idUser!);
    this.dialogRef.close();
  }
}

import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ModalService } from 'src/data/services/modal.service';
import { MoreInfoComponent } from '../more-info/more-info.component';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})
export class MenuComponent {
  menuIcon = [
    {
      icon: 'dashboard',
      selected: true,
      id: 0,
      redirect_to: '/dashboard'
    },
    {
      icon: 'people_outline',
      selected: false,
      id: 1,
      redirect_to: '/users'
    },
    {
      icon: 'help',
      selected: false,
      id: 2,
      redirect_to: '/help'
    },
    // {
    //   icon: 'more_horiz',
    //   selected: false,
    //   id: 3,
    //   redirect_to: '/more_info'
    // }
  ]
  constructor(private router: Router,private modalService: ModalService ) { }

  selectOption(id_option: number) {
    for (const option of this.menuIcon) {
      if (option.id === id_option && id_option != 2) {
        this.router.navigate([option.redirect_to])
        option.selected = true
      }      
      else {
        option.selected = false
      }
    }
    if(id_option === 2){
      this.modalService.open(MoreInfoComponent, () => {
        this.router.navigate(['/dashboard'])
      })
    }
  }
}
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BarLateralComponent } from './bar-lateral/bar-lateral.component';
import { MaterialModule } from '../material/material.module';
import { MenuComponent } from './menu/menu.component';
import { FormsModule } from '@angular/forms';
import { ModalComponent } from './modal/modal.component';
import { MoreInfoComponent } from './more-info/more-info.component';



@NgModule({
  declarations: [
    BarLateralComponent,
    MenuComponent,
    ModalComponent,
    MoreInfoComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    FormsModule
  ],exports: [
    BarLateralComponent,
    MenuComponent,
    ModalComponent
  ]
})
export class SharedModule { }

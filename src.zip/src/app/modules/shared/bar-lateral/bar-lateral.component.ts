import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { GraphicsService } from 'src/data/services/graphics.service';

@Component({
  selector: 'app-bar-lateral',
  templateUrl: './bar-lateral.component.html',
  styleUrls: ['./bar-lateral.component.css'],
})
export class BarLateralComponent implements OnInit {
  @Output() evento = new EventEmitter();
  @Output() evento1 = new EventEmitter();

  productos = [
    {
      name: '',
      selected: false,
    },
  ];

  Especies = [
    {
      name: '',
      selected: false,
    },
  ];

  panelOpenState = false;
  panelOpenState1 = false;
  query: string = '';
  selectedOptionsCategories: string[] = [];
  selected: Date | null | undefined;
  selectedProduct: string = '';
  response_graphics: any = [];

  loadingEspecies = true; // Indicador de carga para las especies
  loadingError = false; // Indicador de error en la conexión

  constructor(public graphcisService: GraphicsService) {}

  async ngOnInit() {
    try {
      const response = await this.graphcisService.getCategoriesList();
      this.Especies = Object.entries(response).map((entry) => ({
        name: entry[0],
        selected: false,
      }));
    } catch (error) {
      console.error('Error al cargar las especies:', error);
      this.loadingError = true;
    } finally {
      this.loadingEspecies = false; // Se detiene el indicador de carga
    }

    try {
      const response1 = await this.graphcisService.getProductsList();
      this.productos = Object.entries(response1).map((entry) => ({
        name: entry[0],
        selected: false,
      }));
    } catch (error) {
      console.error('Error al cargar los productos:', error);
    }
  }

  async onSelectionChange(event: any) {
    this.selectedOptionsCategories = event.source.selectedOptions.selected.map(
      (item: any) => item.value
    );
    let index = 0;
    for (let option of this.selectedOptionsCategories) {
      this.response_graphics[index] = await this.graphcisService.getDatagraphs(
        option
      );
      index++;
    }
    this.evento1.emit(this.response_graphics);
  }

  async onSelectionChangeFood(event: any) {
    const response = await this.graphcisService.getDatacard4(
      this.selectedProduct
    );
    const peticion = Object.entries(response).map((entry) => ({
      name: this.selectedProduct,
      value: entry[1][0],
    }));
    this.evento.emit(peticion);
  }
}

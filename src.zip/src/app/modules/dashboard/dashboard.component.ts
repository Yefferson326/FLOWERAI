import { Component, Input, OnInit } from '@angular/core';
import { GraphicsService } from 'src/data/services/graphics.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit{
  showFiller = false;
  @Input() subtitle_card4 = '';
  @Input() product = '';
  

  view: [number, number] = [700, 400];

  dataGraph1: any = [
    {
      "name": "Germany",
      "value": 8940000
    },
    {
      "name": "USA",
      "value": 5000000
    },
    {
      "name": "France",
      "value": 7200000
    },
    {
      "name": "Italy",
      "value": 4500000
    },
    {
      "name": "Spain",
      "value": 5730000
    },{
      "name": "UK",
      "value": 8200000
    }
  ];

  DataBarChart = [
    {
      "name": "Germany",
      "value": 8940000
    },
    {
      "name": "USA",
      "value": 5000000
    },
    {
      "name": "France",
      "value": 7200000
    }
  ];
  
  cardInfoList = [
    {
      icon: 'book',
      iconBackround: '#FFAA27',
      size: 100,
      title: 'Cantidad de Pedidos',
      subtitle: '',
      iconBottom: 'info',
      footer: 'Numero de pedidos hechos a lo largo del tiempo',
      footerColor: 'orange'
    },
    {
      icon: 'dashboard',
      iconBackround: '#56DFEA',
      size: 100,
      title: 'Numero de empleados',
      subtitle: '',
      iconBottom: 'info',
      footer: 'Cantidad de empleados en la empresa',
      footerColor: '#56DFEA'
    },
    {
      icon: 'dashboard',
      iconBackround: '#F06847',
      size: 100,
      title: 'Numero de clientes',
      subtitle: '',
      iconBottom: 'info',
      footer: 'Cantidad de clientes registrados en la empresa',
      footerColor: '#F06847'
    },
    {
      icon: 'dashboard',
      iconBackround: '#CF5DEE',
      size: 100,
      title: 'Existencias',
      subtitle: '',
      iconBottom: 'info',
      footer: '',
      footerColor: '#CF5DEE'
    },
  ];


  constructor(public graphcisService: GraphicsService) { }

  async ngOnInit() {
    const response= await this.graphcisService.getDatacard1();
    this.cardInfoList[0].subtitle = Object.entries(response)[0][1];

    const response2= await this.graphcisService.getDatacard2();
    this.cardInfoList[1].subtitle = Object.entries(response2)[0][1];

    const response3= await this.graphcisService.getDatacard3();
    this.cardInfoList[2].subtitle = Object.entries(response3)[0][1];

    const response4= await this.graphcisService.getDatagraphic1();
    console.log(response4);
    this.dataGraph1= response4;
}

  recieveData(data: any) {
    console.log("recieveData");
    console.log(data[0]);
    this.cardInfoList[3].subtitle = data[0].value;
    this.cardInfoList[3].footer = "Producto:" + data[0].name;
  }

  recieveDataBarChar(data: any) {
    let datos:any = []; 
    console.log("recieveData");
    console.log(data);
    for(const data_ind of data){
      console.log("DATA INDIVIDUAL");
      console.log(data_ind);
      datos.push(data_ind[0]);
    }
    console.log(datos);
    this.DataBarChart = datos;
  }

  ngAfterViewInit() {
    const chartElement = document.querySelector('#chart-tree');
    
    if (chartElement) {
      const width = chartElement.clientWidth;
      const height = chartElement.clientHeight;
      this.view = [width, height];
      window.addEventListener('resize', () => {
        const width = chartElement.clientWidth;
        const height = chartElement.clientHeight;
        this.view = [width, height];
        console.log(this.view);
      });
    }
    console.log(this.view);
  }

}

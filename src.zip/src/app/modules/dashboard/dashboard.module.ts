import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard.component';
import { MaterialModule } from '../material/material.module';
import { CardInfoComponent } from './components/card-info/card-info.component';
import { GraphicsCardComponent } from './components/graphics-card/graphics-card.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';
import { GraphicsCardTreeMapComponent } from './components/graphics-card-tree-map/graphics-card-tree-map.component';
import { SharedModule } from '../shared/shared.module';



@NgModule({
  declarations: [
    DashboardComponent,
    CardInfoComponent,
    GraphicsCardComponent,
    GraphicsCardTreeMapComponent
  ],
  imports: [
    CommonModule,
    MaterialModule,
    NgxChartsModule,
    SharedModule
  ]
})
export class DashboardModule { }

import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-card-info',
  templateUrl: './card-info.component.html',
  styleUrls: ['./card-info.component.css']
})
export class CardInfoComponent {
  color1 = '#FFAA27'
  color2 = '#F76363'
  @Input() icon: string = 'person'
  @Input() iconBackround: string = '#1F9EC9'
  @Input() size: number = 50
  @Input() title: string = 'Title'
  @Input() subtitle: string = 'Subtitle'
  @Input() iconBottom: string = 'warning'
  @Input() footer: string = 'Content'
  @Input() footerColor: string = 'orange'
}

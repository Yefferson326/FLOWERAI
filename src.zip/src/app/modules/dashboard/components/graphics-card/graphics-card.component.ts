import { group } from '@angular/animations';
import { Component, Input } from '@angular/core';
import { Color, ScaleType } from '@swimlane/ngx-charts';
import { single } from 'rxjs';

@Component({
  selector: 'app-graphics-card',
  templateUrl: './graphics-card.component.html',
  styleUrls: ['./graphics-card.component.css']
})
export class GraphicsCardComponent {
  @Input() title: string = 'Title'
  @Input() subtitle: string = 'Subtitle'
  @Input() iconBottom: string = 'warning'
  @Input() footer: string = 'Content'
  @Input() footerColor: string = 'orange'
  
  view: [number, number] = [0, 0];

  ngAfterViewInit() {
    const chartElement = document.querySelector('#chart');
    
    if (chartElement) {
      const width = chartElement.clientWidth;
      const height = chartElement.clientHeight;
      this.view = [width, height];
      window.addEventListener('resize', () => {
        const width = chartElement.clientWidth;
        const height = chartElement.clientHeight;
        this.view = [width, height];
        console.log(this.view);
      });
    }
    console.log(this.view);
  }

  multi: any[] = [
    {
      "name": "Germany",
      "series": [
        {
          "name": "1990",
          "value": 62000000
        },
        {
          "name": "2010",
          "value": 73000000
        },
        {
          "name": "2011",
          "value": 89400000
        }
      ]
    },
  
    {
      "name": "USA",
      "series": [
        {
          "name": "1990",
          "value": 250000000
        },
        {
          "name": "2010",
          "value": 309000000
        },
        {
          "name": "2011",
          "value": 311000000
        }
      ]
    },
  
    {
      "name": "France",
      "series": [
        {
          "name": "1990",
          "value": 58000000
        },
        {
          "name": "2010",
          "value": 50000020
        },
        {
          "name": "2011",
          "value": 58000000
        }
      ]
    },
    {
      "name": "UK",
      "series": [
        {
          "name": "1990",
          "value": 57000000
        },
        {
          "name": "2010",
          "value": 62000000
        }
      ]
    }
  ];
  

  // options
  legend: boolean = true;
  showLabels: boolean = true;
  animations: boolean = true;
  xAxis: boolean = true;
  yAxis: boolean = true;
  showYAxisLabel: boolean = true;
  showXAxisLabel: boolean = true;
  xAxisLabel: string = 'Year';
  yAxisLabel: string = 'Population';
  timeline: boolean = true;

  colorScheme: Color = {
    group: ScaleType.Linear,
    name: '',
    selectable: true,
    domain: ['#ec7524']
  };
}

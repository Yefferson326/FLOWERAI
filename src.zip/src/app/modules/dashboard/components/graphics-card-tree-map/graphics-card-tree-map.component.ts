import { Component, Input } from '@angular/core';
import { Color, ScaleType } from '@swimlane/ngx-charts';

@Component({
  selector: 'app-graphics-card-tree-map',
  templateUrl: './graphics-card-tree-map.component.html',
  styleUrls: ['./graphics-card-tree-map.component.css']
})
export class GraphicsCardTreeMapComponent {
  @Input() title: string = 'Title'
  @Input() subtitle: string = 'Subtitle'
  @Input() iconBottom: string = 'warning'
  @Input() footer: string = 'Content'
  @Input() footerColor: string = 'orange'

}
